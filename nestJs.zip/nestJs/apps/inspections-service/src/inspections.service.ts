import { Injectable } from '@nestjs/common';

@Injectable()
export class MyAppService {
  getHello(): string {
    return 'Hello ! 🚀 Inspections Service running at: http://localhost:4001';
  }
}
