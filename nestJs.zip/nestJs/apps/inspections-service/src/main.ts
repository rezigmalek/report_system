// apps/attendance-service/src/main.ts
import { NestFactory } from '@nestjs/core';
import { MyAppModule } from './inspections.module';
import { ValidationPipe } from '@nestjs/common';
import { join } from 'path';
import { NestExpressApplication } from '@nestjs/platform-express';

async function bootstrap() {
  try {
    const app = await NestFactory.create<NestExpressApplication>(MyAppModule);

    // Serve static files from the root "uploads" folder (safe for monorepo)
    app.useStaticAssets(join(process.cwd(), 'uploads'), {
      prefix: '/uploads/',
    });

    // Enable CORS
    app.enableCors();
    app.useLogger([ 'log', 'error', 'warn', 'debug', 'verbose' ]);

    // Global validation pipe for DTOs
    app.useGlobalPipes(
      new ValidationPipe({
        whitelist: true,
        transform: true,
      }),
    );

    // Start server
    const port = 4001; // Different port than api-gateway to avoid conflicts
    await app.listen(port);
    console.log(`🚀 Inspections Service running at: http://localhost:${port}`);
  } catch (err) {
    console.error('Failed to bootstrap Inspections Service', err);
    process.exit(1);
  }
}

bootstrap();
