import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('media_attachments')
export class MediaAttachment {
  @PrimaryGeneratedColumn('uuid')
  mediaId: string;

  @Column('uuid')
  reportId: string;

  // local relative path inside uploads/
  @Column()
  relativePath: string;

  @Column()
  fileUrl: string;

  @Column()
  mimeType: string;

  @Column('int')
  size: number;

  @Column({ type: 'int', nullable: true })
  width?: number;

  @Column({ type: 'int', nullable: true })
  height?: number;

  @Column({ nullable: true })
  thumbnailPath?: string;

  @CreateDateColumn({ type: 'timestamp with time zone' })
  uploadedAt: Date;
}
