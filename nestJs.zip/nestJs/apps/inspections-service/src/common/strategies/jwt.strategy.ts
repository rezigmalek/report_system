// jwt.strategy.ts
import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor() {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_SECRET, // Same as api-gateway!
    });
  }

  async validate(payload: any) {
    // What user data do you need in your inspection services?
    // Just userId and roles, or more employee details?
    return { userId: payload.sub, roles: payload.roles };
  }
}