import { Module } from '@nestjs/common';
import { MyAppController } from './inspections.controller';
import { MyAppService } from './inspections.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ReportsModule } from './reports/reports.module';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DB_HOST || 'localhost',
      port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 15432,
      username: process.env.DB_USER || 'postgres',
      password: process.env.DB_PASS || 'postgres',
      database: process.env.DB_NAME || 'users_db',
      autoLoadEntities: true,
      synchronize: true,
    }),
    ReportsModule,
  ],
  controllers: [MyAppController],
  providers: [MyAppService],
})
export class MyAppModule {}
