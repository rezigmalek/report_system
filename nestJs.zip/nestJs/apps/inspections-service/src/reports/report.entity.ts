import { Column, CreateDateColumn, Entity, PrimaryGeneratedColumn, UpdateDateColumn } from 'typeorm';

@Entity('reports')
export class Report {
  @PrimaryGeneratedColumn('uuid')
  reportId: string;

  @Column()
  title: string;

  @Column('text', { nullable: true })
  description?: string;

  @Column({ type: 'enum', enum: ['PENDING', 'IN_PROGRESS', 'RESOLVED', 'REJECTED'], default: 'PENDING' })
  status: 'PENDING' | 'IN_PROGRESS' | 'RESOLVED' | 'REJECTED';

  @Column({ name: 'created_by', type: 'uuid', nullable: true, update: false })
  createdBy?: string; // to track who created the report
  
  @CreateDateColumn({ type: 'timestamp with time zone' })
  createdAt: Date;

  @UpdateDateColumn({ type: 'timestamp with time zone' })
  updatedAt: Date;

  @Column('double precision', { nullable: true })
  latitude?: number;

  @Column('double precision', { nullable: true })
  longitude?: number;

  @Column({ type: 'enum', enum: ['AUTO_GPS', 'MANUAL'], default: 'AUTO_GPS' })
  locationAccuracy: 'AUTO_GPS' | 'MANUAL';

  @Column({ type: 'text', nullable: true })
  addressText?: string;

  @Column({ type: 'enum', enum: ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'], default: 'LOW' })
  priority: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
 
 @Column({ type: 'uuid', nullable: true })
 assignedToUserId?: string;

 @Column({ type: 'timestamp with time zone', nullable: true })
 assignedAt?: Date;

 @Column ('uuid')
 categoryId?: string; // to categorize reports when created

 @Column({ type: 'timestamp with time zone', nullable: true })
 resolvedAt?: Date;

//   @Column({ type: 'int', nullable: true })
//   slaHours?: number;

//   @Column({ type: 'timestamp with time zone', nullable: true })
//   slaDeadline?: Date;

}

  export enum AuditAction {
    REPORT_CREATED = 'REPORT_CREATED',
    REPORT_UPDATED = 'REPORT_UPDATED',
    REPORT_DELETED = 'REPORT_DELETED',
    REPORT_ASSIGNED = 'REPORT_ASSIGNED',
    REPORT_RESOLVED = 'REPORT_RESOLVED',
    REPORT_ATTACHMENT_ADDED = 'REPORT_ATTACHMENT_ADDED',
  }

@Entity('audit_logs')
export class AuditLog {
  @PrimaryGeneratedColumn('uuid')
  auditLogId: string;
  @Column({ type: 'enum', enum: AuditAction })
  action: AuditAction;

  @Column('uuid', { nullable: true })
  userId?: string;

  @Column({ type: 'varchar', length: 100 })
  entityType: string; // e.g., 'Report'

  @Column('uuid', { nullable: true })
  entityId?: string;

  @Column({ type: 'jsonb', nullable: true })
  details?: any;

  @CreateDateColumn()
  timestamp: Date;
}

export enum ReportCategory {
  SAFETY = 'SAFETY',
  MAINTENANCE = 'MAINTENANCE',
  ENVIRONMENTAL = 'ENVIRONMENTAL',
  QUALITY = 'QUALITY',
  SECURITY = 'SECURITY',
  ROAD_INFRASTRUCTURE = 'ROAD_INFRASTRUCTURE',
  TRAFFIC = 'TRAFFIC',
  PUBLIC_SERVICES = 'PUBLIC_SERVICES',
  HEALTH = 'HEALTH',
  EDUCATION = 'EDUCATION',
  UTILITIES = 'UTILITIES',
  COMMUNITY = 'COMMUNITY',
  ECONOMIC = 'ECONOMIC',
  SOCIAL = 'SOCIAL',
  CULTURAL = 'CULTURAL',
  OTHER = 'OTHER',
}

@Entity('report_categories')
export class ReportCategoryEntity {
  @PrimaryGeneratedColumn('uuid')
  categoryId: string;

  @Column({ type: 'enum', enum: ReportCategory, unique: true })
  name: ReportCategory;

  @Column({ type: 'text', nullable: true })
  description?: string;
}