// import { Test, TestingModule } from '@nestjs/testing';
// import { ReportsService } from './reports.service';
// import { Report, AuditAction, AuditLog } from './report.entity';
// import { MediaAttachment } from './media-attachment.entity';
// import { Repository } from 'typeorm';

// const createMockRepo = () => ({
//   create: jest.fn(),
//   save: jest.fn(),
//   findOneBy: jest.fn(),
//   findAndCount: jest.fn(),
//   remove: jest.fn(),
// });

// describe('ReportsService', () => {
//   let service: ReportsService;
//   let reportsRepo: any;
//   let mediaRepo: any;
//   let auditRepo: any;

//   beforeEach(async () => {
//     reportsRepo = createMockRepo();
//     mediaRepo = createMockRepo();
//     auditRepo = createMockRepo();

//     const module: TestingModule = await Test.createTestingModule({
//       providers: [
//         ReportsService,
//         { provide: 'REPORTS_REPOSITORY', useValue: reportsRepo },
//         { provide: 'MEDIA_REPOSITORY', useValue: mediaRepo },
//         { provide: 'AUDIT_REPOSITORY', useValue: auditRepo },
//       ],
//     }).compile();

//     service = new ReportsService(reportsRepo as Repository<Report>, mediaRepo as Repository<MediaAttachment>, auditRepo as Repository<AuditLog>);
//   });

//   it('sets createdBy on create', async () => {
//     const dto = { title: 'X' } as any;
//     const created = { reportId: 'rid', ...dto, createdBy: 'user-1' } as Report;
//     reportsRepo.create.mockReturnValue(created);
//     reportsRepo.save.mockResolvedValue(created);

//     const res = await service.create(dto, 'user-1');
//     expect(res.createdBy).toBe('user-1');
//     expect(auditRepo.save).toHaveBeenCalledWith(expect.objectContaining({ action: AuditAction.REPORT_CREATED }));
//   });

//   it('allows admin to update', async () => {
//     const existing = { reportId: 'rid', createdBy: 'user-1', title: 'old' } as Report;
//     reportsRepo.findOneBy.mockResolvedValue(existing);
//     reportsRepo.save.mockImplementation(async (r) => r);

//     const updated = await service.update('rid', { title: 'new' }, { userId: 'user-2', roles: ['ADMIN'] });
//     expect(updated.title).toBe('new');
//   });

//   it('forbids non-owner non-admin update', async () => {
//     const existing = { reportId: 'rid', createdBy: 'user-1', title: 'old' } as Report;
//     reportsRepo.findOneBy.mockResolvedValue(existing);
//     await expect(service.update('rid', { title: 'new' }, { userId: 'user-2', roles: [] })).rejects.toThrow();
//   });
// });
