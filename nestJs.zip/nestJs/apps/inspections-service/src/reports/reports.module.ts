import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ReportsController } from './reports.controller';
import { ReportsService } from './reports.service';
import { Report,AuditLog } from './report.entity';
import { MediaAttachment } from '../media/media-attachment.entity';

@Module({
  imports: [
    TypeOrmModule.forFeature([
      Report,
      MediaAttachment,
      AuditLog
    ]),
  ],
  controllers: [ReportsController],
  providers: [ReportsService],
})
export class ReportsModule {}
