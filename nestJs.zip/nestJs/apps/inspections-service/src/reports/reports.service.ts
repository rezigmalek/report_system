import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { AuditLog, Report, AuditAction } from './report.entity';
import { CreateReportDto } from './dto/create-report.dto';
import { MediaAttachment } from '../media/media-attachment.entity';
import { join } from 'path';
import {ForbiddenException} from '@nestjs/common/exceptions';

    

@Injectable()
export class ReportsService {
  constructor(
    @InjectRepository(Report)
    private reportsRepo: Repository<Report>,
    @InjectRepository(MediaAttachment)
    private mediaRepo: Repository<MediaAttachment>,
    @InjectRepository(AuditLog) 
    private auditRepo: Repository<AuditLog>,
  ) {}

  private readonly logger = new Logger(ReportsService.name);


  async findAll(option?: { skip?: number; take?: number }): Promise<{ data: Report[]; total: number } | Report[]> {
    // fetch all reports with pagination
    const [data, total] = await this.reportsRepo.findAndCount({
      skip: option?.skip,
      take: option?.take,
      order: ( { createdAt: 'DESC' } as unknown) as import('typeorm').FindOptionsOrder<Report>,
    });
    // to return paginated data if pagination params are provided
    if (option?.skip !== undefined && option?.take !== undefined) {
      return { data, total };
    }
    return data;
  }

  async findOne(reportId: string) {
    const r = await this.reportsRepo.findOneBy({ reportId });
    if (!r) throw new NotFoundException(`Report with id ${reportId} not found`);
    return r;
  }

  async create(dto: any, createdBy?: string) {
    const r = this.reportsRepo.create({ ...dto, createdBy });
    const saved = await this.reportsRepo.save(r);
    this.logger.debug('Report created:', saved);

    // audit log
    await this.auditRepo.save({
      action: AuditAction.REPORT_CREATED,
      userId: createdBy,
      entityType: 'Report',
      // entityId:saved.reportId,
      details: saved,
    });

    return saved;
  }
    
  async update(id: string, dto: any, user?: { userId?: string; roles?: string[] }) {
    const report = await this.findOne(id);
    if (!report) {
      throw new NotFoundException(`Report with id ${id} not found`);
    }

    const uid = user?.userId;
    const roles = user?.roles || [];

    // allow update if owner or ADMIN/INSPECTOR role
    if (report.createdBy !== uid && !roles.includes('ADMIN') && !roles.includes('INSPECTOR')) {
      throw new ForbiddenException('You are not allowed to update this report');
    }

    Object.assign(report, dto);
    const updated = await this.reportsRepo.save(report);

    // debug log
    this.logger.debug('Report updated:', updated);

    // audit log 
    // you may want to store before/after snapshots in the future for more detailed audit trails
    await this.auditRepo.save({
      action: AuditAction.REPORT_UPDATED,
      userId: uid,
      entityType: 'Report',
      entityId: updated.reportId,
      details: updated,
    });
    return updated;
  }

  async remove(reportId: string, user?: { userId?: string; roles?: string[] }) {
    const report = await this.findOne(reportId);
    const uid = user?.userId;
    const roles = user?.roles || [];

    if (report.createdBy !== uid && !roles.includes('ADMIN') && !roles.includes('INSPECTOR')) {
      throw new ForbiddenException({
        message:
              {
                EN:'You are not allowed to delete this report',
                FR:'Vous n\'êtes pas autorisé à supprimer ce rapport',
                AR:'ليس لديك إذن لحذف هذا التقرير'
              }
      });
    }
    const removed = await this.reportsRepo.remove(report);
    this.logger.debug('Report removed:', removed);
    await this.auditRepo.save({
      action: AuditAction.REPORT_DELETED,
      userId: uid,
      entityType: 'Report',
      entityId: removed.reportId,
      details: removed,
    });
    return removed;
  }


  // async update(reportId: string,dto: CreateReportDto, userId?: any) {
  //   const r = await this.findOne(reportId);
  //   if (r.createdBy !== userId && !userId?.roles?.includes('ADMIN')) {
  //     throw new ForbiddenException({
  //       message:{
  //                 EN:'You are not allowed to update this report',
  //                 FR:'Vous n\'êtes pas autorisé à mettre à jour ce rapport',
  //                 AR:'ليس لديك إذن لتحديث هذا التقرير'
  //               }
  //     });
  //   }
  //   Object.assign(r, dto);
  //   return this.reportsRepo.save(r);
  // }

  // async remove(reportId: string) {
  //   const r = await this.findOne(reportId);
  //   return this.reportsRepo.remove(r);
  // }

  async addAttachment(reportId: string, relativePath: string, originalName: string, mimetype: string, size: number, userId?: string) {
    // ensure report exists
    await this.findOne(reportId);

    const fileUrl = join('/uploads', relativePath).replace(/\\/g, '/');
    const media = this.mediaRepo.create({ reportId, relativePath, fileUrl, mimeType: mimetype, size });
    const saved = await this.mediaRepo.save(media);

    // audit the attachment
    await this.auditRepo.save({
      action: AuditAction.REPORT_ATTACHMENT_ADDED,
      userId: userId,
      entityType: 'Report',
      entityId: reportId,
      details: { mediaId: saved.mediaId, relativePath: saved.relativePath, originalName },
    });

    return saved;
  }
}