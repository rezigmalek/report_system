import { Body, Controller, Get, Param, Post, UploadedFile, UseInterceptors, BadRequestException, Query, HttpStatus, NotFoundException, HttpException, ParseUUIDPipe, Put, UseGuards } from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { join, basename } from 'path';
import { ReportsService } from './reports.service';
import { CreateReportDto } from './dto/create-report.dto';
import sharp from 'sharp';
import { promises as fs } from 'fs';
import {Report} from './report.entity';
import {ListReportsDto} from './dto/list-reports.dto';
import { AuthGuard } from '@nestjs/passport';
import { ForbiddenException } from '@nestjs/common/exceptions';
import { CurrentUser } from './decorator/CurrentUser.decorator';

@Controller('reports')
export class ReportsController {
  constructor(private readonly reportsService: ReportsService) {}

  @Get()
  async findAll(@Query() query : ListReportsDto) {
    const { page, limit } = query;
    try {
        const result = await this.reportsService.findAll({
            skip: (page - 1) * limit,
            take: limit,
        });
        const { data: reports, total } = result as { data: Report[]; total: number };
        return {
            message: {
                EN:'reports fetched successfully',
                FR:'rapports récupérés avec succès',
                AR:'تم جلب التقارير بنجاح'
            },
            data: reports,
            meta: {
                total,
                page,
                limit,
                pages: Math.ceil(total / limit),
                hasNextPage: page * limit < total,
                hasPreviousPage: page > 1,
            },
        };
      } catch (error) {
          if (error instanceof NotFoundException) throw error;
          throw new HttpException(
              {
                  error:{
                      EN:'Failed to fetch reports',
                      FR:'Échec de la récupération des rapports',
                      AR:'فشل في جلب التقارير'
                  }
              },
            HttpStatus.INTERNAL_SERVER_ERROR);
      }
    }

  @Get(':id')
  async findOne(@Param('id', new ParseUUIDPipe()) id: string) {
    try {
      const report = await this.reportsService.findOne(id);
      if (!report) {
        throw new NotFoundException({
          error:{
              EN:'Report id is not found',
              FR:'L\'identifiant du rapport est introuvable',
              AR:'معرف التقرير غير موجود'
          }
        });
      }
      return report;
    } catch (error) {
      if (error instanceof NotFoundException) throw error;
      throw new HttpException(
        {
            error:{
                EN:'Failed to fetch report',
                FR:'Échec de la récupération du rapport',
                AR:'فشل في جلب التقرير'
            }
        },
        HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Post()
  @UseGuards(AuthGuard('jwt'))
  async create(@Body() dto: CreateReportDto, @CurrentUser() user: any) {
    try {
      const createdByUserId = user?.userId;
      const report =  await this.reportsService.create(dto, createdByUserId);
      return {
          message: {
              EN:'Report created successfully',
              FR:'Rapport créé avec succès',
              AR:'تم إنشاء التقرير بنجاح'
          },
          data: report,
      };
    } catch (error) {
        throw new HttpException(
            {
                error:{
                    EN:'Failed to create report',
                    FR:'Échec de la création du rapport',
                    AR:'فشل في إنشاء التقرير'
                }
            },
          HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @Post(':id/attachments')
  @UseGuards(AuthGuard('jwt'))
  @UseInterceptors(FileInterceptor('file', {
    storage: diskStorage({
      destination: (req, file, cb) => cb(null, join(process.cwd(), 'uploads', 'reports')),
      filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname.replace(/\s+/g,'_')}`),
    }),
    limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
  }))
  async upload(@Param('id') id: string, @UploadedFile() file: Express.Multer.File, @CurrentUser() user: any) {
    if (!file) throw new BadRequestException('No file uploaded');

    // Only allow images for MVP
    if (!file.mimetype.startsWith('image/')) {
      await fs.unlink(file.path).catch(() => {}); 
      throw new BadRequestException('Only image uploads are allowed');
    }

    // Compress/resize with sharp
    const tmpPath = `${file.path}.tmp`;
    await sharp(file.path).resize({ width: 1600, withoutEnlargement: true }).jpeg({ quality: 80 }).toFile(tmpPath);
    await fs.rename(tmpPath, file.path);

    const relativePath = join('reports', basename(file.path)).replace(/\\/g, '/');
    const media = await this.reportsService.addAttachment(id, relativePath, file.originalname, file.mimetype, file.size, user?.userId);
    return media;
  }

@Put(':id')
  @UseGuards(AuthGuard('jwt'))
  async update(@Param('id', new ParseUUIDPipe()) id: string, @Body() dto: CreateReportDto, @CurrentUser() user: any) {
    try {
      const report = await this.reportsService.update(id, dto, { userId: user?.userId, roles: user?.roles });
      return {
          message: {
              EN:'Report updated successfully',
              FR:'Rapport mis à jour avec succès',
              AR:'تم تحديث التقرير بنجاح'
          },
          data: report,
      };
    } catch (error) {
        if (error instanceof NotFoundException) throw error;
        if (error instanceof ForbiddenException) throw error;
        throw new HttpException(
            {
                error:{
                    EN:'Failed to update report',
                    FR:'Échec de la mise à jour du rapport',
                    AR:'فشل في تحديث التقرير'
                }
            },
          HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

}