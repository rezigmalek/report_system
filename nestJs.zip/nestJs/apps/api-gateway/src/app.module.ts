import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { EmployeesModule } from './employees/employees.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AccountsModule } from './accounts/accounts.module';
import { AuthModule } from './auth/auth.module';



@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: process.env.DB_HOST || 'localhost',
      // port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 5432,
      port: process.env.DB_PORT ? Number(process.env.DB_PORT) : 15432,

      username: process.env.DB_USER || 'postgres',
      password: process.env.DB_PASS || 'postgres',
      database: process.env.DB_NAME || 'users_db',
      // entities: [__dirname + '/**/*.entity{.ts,.js}'],
      synchronize: true, // use migrations for schema changes

      //“Register every entity used in any TypeOrmModule.forFeature() automatically.”
      autoLoadEntities: true,
    }),
    
    //microservice example with redis
    //client.module.register({
    //  name: 'REDIS_CLIENT',
    //  host: 'localhost',
    //  port: 6379,
    //  db: 0,
    //}),

    EmployeesModule,
    AccountsModule,
    AuthModule
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
