export enum ErrorCode {
  // Generic
  UnknownError = 'UNKNOWN_ERROR',
  ValidationFailed = 'VALIDATION_FAILED',

  // Users
  UserNotFound = 'USER_NOT_FOUND',
  UserEmailConflict = 'USER_EMAIL_CONFLICT',
}

export type ApiErrorPayload = {
  code: ErrorCode;
  message: string;
  details?: unknown;
};
