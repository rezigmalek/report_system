
const secret = '3d6f91c2b6ac7d6a5d5b77d3ef20a918bbf9e19f39f5b2815e3c13b6726a9f21e6af50a3513f8735a9d03ebfb65a07a1eae3d4a0b123f76a2c2c8e2921af914c';

export const jwtConstants = {
    secret: secret,
    expiresIn: '1h',
};