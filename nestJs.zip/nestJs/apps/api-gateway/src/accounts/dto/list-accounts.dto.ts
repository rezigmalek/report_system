import { Transform } from "class-transformer";
import {IsInt, Max, Min} from "class-validator";

export class ListAccountsDto {
    @Transform(({ value }) =>(value !== undefined ? parseInt(value, 10) : 1))
    @IsInt()
    @Min(1)
    page =1; 

    @Transform(({ value }) =>value !== undefined ? parseInt(value, 10) : 10)
    @IsInt()
    @Min(1)
    @Max(100)
    limit =10;
}