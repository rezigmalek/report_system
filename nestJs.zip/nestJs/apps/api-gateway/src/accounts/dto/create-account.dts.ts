import { IsNotEmpty, IsOptional, IsEnum, IsUUID, IsString, MinLength, IsEmail } from "class-validator";
import { accountRole } from "./account-role.enum";


export class CreateAccountDto {
    @IsNotEmpty()
    @IsString()
    username: string;

    @IsOptional()
    @IsEmail()
    email: string;

    @IsNotEmpty()
    @IsString()
    @MinLength(6)
    password: string;
    
    @IsOptional()
    @IsEnum(accountRole)
    role?: accountRole;

    // @IsOptional()
    @IsUUID()
    employeeId?: string | null;
}

