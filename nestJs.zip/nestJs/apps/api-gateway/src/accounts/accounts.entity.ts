import { Entity, PrimaryGeneratedColumn, Column, Check, OneToOne, JoinColumn } from "typeorm";
import { Employees } from '../employees/employees.entity';
import { accountRole } from "./dto/account-role.enum";

// Ensure that if the role is USER, employeeId must not be null
@Check(`"role" != 'USER' OR "employeeId" IS NOT NULL`)
@Entity('accounts')
export class Account {
    @PrimaryGeneratedColumn('uuid')
    userId: string;

    @Column({ unique: true })
    username: string;

    @Column({ unique: true, nullable: true })
    email?: string | null;
    

    @Column()
    passwordHash: string;

    @Column({type : 'enum', enum: accountRole, default: accountRole.USER})
    role: accountRole;

    @Column({ type: 'uuid', nullable: true, unique: true })
    employeeId: string | null;

    @OneToOne(() => Employees, { nullable: true })
    @JoinColumn({ name: 'employeeId' })
    employee?: Employees;
    get employeeEmail(): string | undefined {
        return this.employee?.email;
    }
}