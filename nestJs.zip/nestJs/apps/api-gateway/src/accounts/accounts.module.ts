import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Account } from './accounts.entity';
import {AccountsService} from './accounts.service';
import {AccountsController} from './accounts.controller';
import { Employees } from '../employees/employees.entity';

@Module({
    imports: [TypeOrmModule.forFeature([Account,Employees])],
    controllers: [AccountsController],
    providers: [AccountsService],
    exports: [AccountsService],
})
export class AccountsModule {}
