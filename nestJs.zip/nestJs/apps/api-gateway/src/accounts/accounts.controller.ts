import { AccountsService } from './accounts.service';
import { Account } from './accounts.entity';
import {ListAccountsDto} from './dto/list-accounts.dto';
import { CreateAccountDto } from './dto/create-account.dts';
import {Controller,Get,Post,Put,Delete,Param,Body,Query,HttpCode,HttpStatus,ParseIntPipe,NotFoundException,HttpException, ParseUUIDPipe,} from '@nestjs/common';

@Controller('accounts')
export class AccountsController {
    constructor(private readonly accountsService: AccountsService) { }

    @Get()
    async findAll(
        @Query() query : ListAccountsDto) {
        const { page, limit } = query;
        try {
            const result = await this.accountsService.findAll({
                skip: (page - 1) * limit,
                take: limit,
            });
            const { data: accounts, total } = result as { data: Account[]; total: number };
            return {
                message: {
                    EN:'accounts fetched successfully',
                    FR:'comptes récupérés avec succès',
                    AR:'تم جلب الحسابات بنجاح'
                },
                data: accounts,
                meta: {
                    total,
                    page,
                    limit,
                    pages: Math.ceil(total / limit),
                    hasNextPage: page * limit < total,
                    hasPreviousPage: page > 1,
                },
            };
        } catch (error) {
            if (error instanceof NotFoundException) throw error;
            throw new HttpException(
                {
                    error:{
                        EN:'Failed to fetch accounts',
                        FR:'Échec de la récupération des comptes',
                        AR:'فشل في جلب الحسابات'
                    }
                },
                HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

        @Get(':userId')
        async findOne(@Param('userId', new ParseUUIDPipe()) userId: string) {
            try {
                const account = await this.accountsService.findOne(userId);
                if (!account) {
                throw new NotFoundException({
                    error:{
                        EN:'Account id is not found',
                        FR:'L\'identifiant du compte est introuvable',
                        AR:'معرف الحساب غير موجود'
                    },
                });
                }
                return account; // return the found account
            } catch (error) {
                throw new NotFoundException({
                    error: {
                        EN:'Account is not found',
                        FR:'Compte introuvable',
                        AR:'الحساب غير موجود'
                    }
                });
            }
        

    }

        @Post()
        async create(@Body() accountData: CreateAccountDto) {
            try {
                const account = await this.accountsService.create(accountData);
                return {
                    message: {
                        ENG:'Account created successfully',
                        FR:'Compte créé avec succès',
                        AR:'تم إنشاء الحساب بنجاح'
                    },
                    data: account,
                };
            } catch (error) {
                if(error instanceof NotFoundException) throw error;
                throw new HttpException({
                        error: {
                        ENG:'Failed to create an account',
                        FR:'Échec de la création du compte',
                        AR:'فشل في إنشاء الحساب'    
                    }
                },
                    HttpStatus.INTERNAL_SERVER_ERROR,
                );
            }
        }

        @Put(':userId')
        async update(@Param('userId', new ParseUUIDPipe()) userId: string, @Body() accountData: any) {
            try {
                const updatedAccount = await this.accountsService.update(userId, accountData);
                if (!updatedAccount) {
                    throw new HttpException({ error: 'Account not found' }, HttpStatus.NOT_FOUND);
                }
                return {
                    message: {
                        ENG:'Account updated successfully',
                        FR:'Compte mis à jour avec succès',
                        AR:'تم تحديث الحساب بنجاح'
                    },
                    data: updatedAccount,
                };
            } catch (error) {
                throw new HttpException(
                    { error: 'Failed to update account' },
                    HttpStatus.INTERNAL_SERVER_ERROR,
                );
            }
        }

        @Delete(':userId')
        @HttpCode(HttpStatus.NO_CONTENT)
        async remove(@Param('userId', new ParseUUIDPipe()) userId: string) {
            try {
                await this.accountsService.remove(userId);
            } catch (error) {
                if (error instanceof NotFoundException) throw error;
                throw new HttpException({
                    error: {
                        EN:'Failed to delete account',
                        FR:'Échec de la suppression du compte',
                        AR:'فشل في حذف الحساب'
                    } },
                    HttpStatus.INTERNAL_SERVER_ERROR,
                );
            }
        }
}