import { Injectable, NotFoundException, BadRequestException } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";
import { Account } from "./accounts.entity";
import { Employees } from '../employees/employees.entity';
import * as bcrypt from "bcryptjs";


@Injectable()
export class AccountsService {
    constructor(
        @InjectRepository(Account)
        private accountsRepo: Repository<Account>,
        @InjectRepository(Employees)
        private employeesRepo: Repository<Employees>,
    ) {}

    async findAll(options?: { skip?: number; take?: number }): Promise<{data: Account[]; total: number} | Account[] >  {
        // fetch all accounts with pagination
        const [data, total] = await this.accountsRepo.findAndCount({
            skip: options?.skip,
            take: options?.take,
            order: ({ userId: "ASC" } as unknown) as import("typeorm").FindOptionsOrder<Account>,
        });
        // to return paginated data if pagination params are provided
        if (options?.skip !== undefined && options?.take !== undefined) {
            return { data, total };
        }
        return data;
    }

    async findByUsername(username: string): Promise<Account | null> {
        return this.accountsRepo.findOne({ where: { username }, relations: ['employee'] });
    }

    async findOne(id: string): Promise<Account > {
        const account = await this.accountsRepo.findOneBy({ userId: id });
        if (!account) throw new NotFoundException(`Account with id ${id} not found`);
        return account;
    }

    async create(accountData: any): Promise<Account> {
        if (!accountData.username) throw new BadRequestException('Username is required');
        if (!accountData.password) throw new BadRequestException('Password is required');  
        
        // if an employeeId is provided, validate and copy their email into account.email
        if (accountData.employeeId) {
            const employee =  await this.employeesRepo.findOneBy({ employeeId: accountData.employeeId });
            if (!employee) {
                throw new BadRequestException(`Employee with id ${accountData.employeeId} not found`);
            } else {
                accountData.employeeId = employee.employeeId ?? null;
                accountData.email = employee.email ?? null ;
            }
        }    
        // removing the password and keepint it hashed for security perpose
        accountData.passwordHash = await bcrypt.hash(accountData.password, 10);
        delete accountData.password;
        
        // hashing the password before saving
        const account = this.accountsRepo.create({ ...accountData, passwordHash: accountData.passwordHash  }); // create a new account instance
        const saved = await this.accountsRepo.save(account);
        return saved as unknown as Account;
    }

    async update(id: string , accountData: any): Promise<Account | null> {
        if (accountData.password) {
            accountData.passwordHash = await bcrypt.hash(accountData.password, 10);
            delete accountData.password;
        }

        if (accountData.employeeId) {
            const employee =  await this.employeesRepo.findOneBy({ employeeId: accountData.employeeId });
            if (!employee) {
                throw new BadRequestException(`Employee with id ${accountData.employeeId} not found`);
            } else {
                accountData.employeeId = employee.employeeId ?? null;
                accountData.email = employee.email ?? null ;
            }
        }

        await this.accountsRepo.update(id, accountData);
        return this.accountsRepo.findOne({where: {userId: id},relations: ['employee']});
    }

    async remove(id: string): Promise<void> {
        const result = await this.accountsRepo.delete({userId:id});
        if (result.affected || result.affected === 0) {
            throw new NotFoundException(`Account with id ${id} not found`);
        }
        return ;
    }
}