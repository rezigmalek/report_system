import { Injectable } from '@nestjs/common';

@Injectable()
export class AppService {
  getHello(): string {
    return 'Hello World! 🚀Gateway Service running at: http://localhost:4000 with No errors.';
  }
}
