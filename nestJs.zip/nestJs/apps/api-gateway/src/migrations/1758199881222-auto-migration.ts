import { MigrationInterface, QueryRunner } from "typeorm";

export class AutoMigration1758199881222 implements MigrationInterface {
    name = 'AutoMigration1758199881222'

    public async up(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`CREATE TYPE "public"."user_department_enum" AS ENUM('Engineering', 'Marketing', 'Sales', 'Human Resources', 'Finance', 'Support')`);
        await queryRunner.query(`CREATE TYPE "public"."user_role_enum" AS ENUM('Manager', 'Designer', 'Imployee', 'Contractor', 'Intern', 'Other')`);
        await queryRunner.query(`CREATE TABLE "user" ("id" SERIAL NOT NULL, "name" character varying NOT NULL, "email" character varying NOT NULL, "date" character varying NOT NULL, "department" "public"."user_department_enum" NOT NULL, "role" "public"."user_role_enum" NOT NULL, "phone" character varying NOT NULL, CONSTRAINT "UQ_e12875dfb3b1d92d7d7c5377e22" UNIQUE ("email"), CONSTRAINT "PK_cace4a159ff9f2512dd42373760" PRIMARY KEY ("id"))`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`DROP TABLE "user"`);
        await queryRunner.query(`DROP TYPE "public"."user_role_enum"`);
        await queryRunner.query(`DROP TYPE "public"."user_department_enum"`);
    }

}
