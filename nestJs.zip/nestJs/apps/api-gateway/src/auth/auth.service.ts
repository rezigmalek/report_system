import { Injectable, UnauthorizedException } from '@nestjs/common';
import { AccountsService } from '../accounts/accounts.service';
import * as bcrypt from 'bcrypt';
import { JwtService } from '@nestjs/jwt';
@Injectable()
export class AuthService {
    constructor(
        private readonly accountsService: AccountsService,
        private readonly jwtService: JwtService,
    ) {}
    
    //Compares a plain-text password with its hashed version using bcrypt.
    private async comparePassword(password: string, hash: string): Promise<boolean> {
        return await bcrypt.compare(password, hash);
    }

    async validateUser(username: string, password: string): Promise<{accessToken: string}> {
        const account = await this.accountsService.findByUsername(username);
        if(!account){
            throw new UnauthorizedException({
                error: {
                    EN: 'Invalid username or password',
                    FR: 'Nom d\'utilisateur ou mot de passe invalide',
                    AR: 'اسم المستخدم أو كلمة المرور غير صالحة'
                }
            });
        }
        if (await this.comparePassword(password, account.passwordHash)) {
            const { passwordHash, ...result } = account;
            const payload = { username: result.username, sub: result.userId, role: result.role };
            const accessToken = await this.jwtService.signAsync(payload);
            return { accessToken };
        }
        throw new UnauthorizedException({
            error: {
                EN: 'Invalid username or password',
                FR: 'Nom d\'utilisateur ou mot de passe invalide',
                AR: 'اسم المستخدم أو كلمة المرور غير صالحة'
            }
        });
    }
    
}



