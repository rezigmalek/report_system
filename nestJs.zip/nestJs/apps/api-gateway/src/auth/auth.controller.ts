import { AuthService } from './auth.service';
import { Body, Post, Controller,HttpCode, HttpStatus  } from '@nestjs/common';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}
  @HttpCode(HttpStatus.OK)
  @Post('login')
  async login(@Body() body: { username: string; password: string }) {
    const user = await this.authService.validateUser(body.username, body.password);
    return {
      message: {
        EN: 'Login successful',
        FR: 'Connexion réussie',
        AR: 'تسجيل الدخول ناجح'
      },
      data: user,
    };
  }
  
}
