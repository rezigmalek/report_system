import { Module } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { JwtModule } from '@nestjs/jwt';
import { AccountsModule } from '../accounts/accounts.module';
import { jwtConstants } from '../constants';

@Module({
  imports: [
    AccountsModule,
    JwtModule.register({
      // registering it as global so it can be used across the application (without importing it` again)
      global: true,
      secret: jwtConstants.secret,
      signOptions: { expiresIn: '24h' },
    }),
  ],
  providers: [AuthService,],
  controllers: [AuthController],
  exports: [AuthService],
})
export class AuthModule {}
