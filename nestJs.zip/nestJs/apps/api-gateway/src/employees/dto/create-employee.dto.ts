import { IsEmail, IsNotEmpty, IsDateString, IsNumberString, IsEnum} from 'class-validator';

export enum DerpatementEnum{
    Engineering="Engineering",
    Marketing="Marketing",
    Sales="Sales",
    HR="HR",
    Finance="Finance",
    Support="Support",
}

export enum RoleEnum{
    Manager="Manager",
    Designer="Designer",
    Imployee="Imployee",
    Contractor="Contractor",
    Intern="Intern",
    Other="Other",
}

export class CreateEmployeeDto {
    @IsNotEmpty()
    name: string;

    @IsEmail()
    email: string;

    @IsDateString()
    date:string;

    @IsNumberString()
    phone:string;

    @IsEnum(DerpatementEnum)
    department:DerpatementEnum;

    @IsEnum(RoleEnum)
    role:RoleEnum;

}