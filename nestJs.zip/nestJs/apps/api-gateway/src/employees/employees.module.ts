import { Module } from '@nestjs/common';
import { EmployeesController } from './employees.controller';
import { employeesService } from './employees.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Employees } from './employees.entity'
@Module({
  imports: [TypeOrmModule.forFeature([Employees])],
  controllers: [EmployeesController],
  providers: [employeesService]
})
export class EmployeesModule {}
