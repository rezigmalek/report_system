import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Employees } from './employees.entity'
import { CreateEmployeeDto } from './dto/create-employee.dto';



@Injectable()
export class employeesService {
    constructor(
        @InjectRepository(Employees) private employeesRepo: Repository<Employees>
    ){}
    // ✅ Pagination: returns [employees, totalCount]
    async findAll(options?: { skip?: number; take?: number }): Promise<[Employees[], number]> {
        const [employees, total] = await this.employeesRepo.findAndCount({
            skip: options?.skip,
            take: options?.take,
            order: ({ employeeId: 'ASC' } as unknown) as import("typeorm").FindOptionsOrder<Employees>,
        });
        // If you’re serving images from /uploads, attach full URL
        const employeesWithFullAvatarPath = employees.map(employee => ({
            ...employee,
            avatar: employee.avatar ? `${process.env.BASE_URL}/uploads/${employee.avatar}` : null,
        }));
        return [employeesWithFullAvatarPath, total];

    }

    findOne(id: string){
        return this.employeesRepo.findOneBy({ employeeId: id });
    }
    create(employeeData: any, avatarePath: string){
        if (avatarePath) {
            employeeData.avatar = avatarePath;
        }
        const employee = this.employeesRepo.create(employeeData);
        return this.employeesRepo.save(employee);
    }

     
    update(id: number, employeeData: any){
        return this.employeesRepo.update(id,employeeData);
    }


    remove(id: number){
        return this.employeesRepo.delete(id);
    }

    
}
