import { Controller, Get,Put,Post,Delete,Body,Param, NotFoundException, HttpException, Query, UseInterceptors, UploadedFile,  } from '@nestjs/common';
import {employeesService} from './employees.service';
import { NotFoundError } from 'rxjs';
import { ErrorCode } from '../common/error-codes';
import {HttpStatus} from '@nestjs/common' ;
import { InternalServerErrorException } from '@nestjs/common';
import { ListEmployeesDto } from './dto/list-employees.dto';
import {diskStorage} from 'multer';
import { extname } from 'path';
import {CreateEmployeeDto} from './dto/create-employee.dto';
import { FileInterceptor } from '@nestjs/platform-express';


//api route (http://localhost:4000/employees)
@Controller('employees')
export class EmployeesController {
    constructor(private readonly employeesService: employeesService) { }

    @Get()
    async findAll(@Query() query: ListEmployeesDto) {
        const { page, limit } = query;
        try {
            const [employees, total] = await this.employeesService.findAll({
                skip: (page - 1) * limit,
                take: limit,
            });

            return {
                message: {
                ENG:'employees fetched successfully',
                FR:'employés récupérés avec succès',
                AR:'تم جلب الموظفين بنجاح'
                },
                data: employees,
                meta: {
                    total,
                    page,
                    limit,
                    pages: Math.ceil(total / limit),
                    hasNextPage: page * limit < total,
                    hasPreviousPage: page > 1,
                },
            };
        } catch (error) {
            throw new HttpException(
                { error: 'failed to fetch employees' },
                HttpStatus.INTERNAL_SERVER_ERROR
            );
        }
    }

    
    @Get(':id')
    async findOne(@Param('id') id: string) {
        try {
            const employee = await this.employeesService.findOne(id);
            if (!employee) {
            throw new HttpException({ error: 'employee not found' }, HttpStatus.NOT_FOUND);
            }
            return employee; // ✅ RETURN  employees
        } catch (error) {
            throw new HttpException({ error: 'employee not found' }, HttpStatus.NOT_FOUND);
        }
    }


    @Post()
    @UseInterceptors(FileInterceptor('avatar',{
        storage:diskStorage({
            destination:'./uploads/employees',
            filename:(
                _req: Express.Request,
                file: Express.Multer.File,
                callback : (error : Error | null ,filename:string)  => void) => {
                const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
                const ext = extname(file.originalname);
                callback(null, `${uniqueSuffix}${ext}`);
            }
        })
    }))
    async   create(@UploadedFile() file: Express.Multer.File,
    @Body() createEmployeeDto: CreateEmployeeDto){
        const avatarePath = file ? file.filename:null;
        return this.employeesService.create(createEmployeeDto, avatarePath);
    }

    @Put(':id')
    async update(@Param('id') id: string, @Body() employeeData: any) {
        try {
            await this.employeesService.update(+id, employeeData);
        }catch(error){
            throw new HttpException({error:''},HttpStatus.BAD_REQUEST);
        }
    }
    @Delete(':id')
    async remove(@Param('id') id: string) {
        try  {
            await this.employeesService.remove(+id);
        }catch (error){
            throw new HttpException('',HttpStatus.BAD_REQUEST)
        }
    }
}
export class AppController{
    @Get('health')
    healthCheck(): string {
        return 'OK';
    }
}
