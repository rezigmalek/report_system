import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';
import { RoleEnum, DerpatementEnum } from './dto/create-employee.dto';

@Entity('employees')
export class Employees {
    @PrimaryGeneratedColumn('uuid')
    employeeId: string;

    @Column()
    name: string;

    @Column({ unique: true })
    email: string;

    @Column()
    date:string;

    @Column({type: 'enum', enum:DerpatementEnum})
    department:DerpatementEnum;

    @Column({type:"enum", enum:RoleEnum})
    role:RoleEnum;

    @Column()
    phone:string;

    @Column({ nullable: true })
    avatar?: string;
}

