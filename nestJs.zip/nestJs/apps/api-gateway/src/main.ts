import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
// import { CreateEmployeeDto } from "./employees/dto/create-employee.dto"
import { ValidationPipe } from '@nestjs/common';
import {join} from 'path'
import { NestExpressApplication } from '@nestjs/platform-express';

async function bootstrap() {
  const app = await NestFactory.create<NestExpressApplication>(AppModule);
  // app.useStaticAssets(join(__dirname,'..','uploads'),
  app.useStaticAssets(join(process.cwd(),'uploads'),
  {
    prefix:'/uploads/'
  });
  app.enableCors();
  app.useGlobalPipes(new ValidationPipe(
    {whitelist:true,
    transform:true,
    })
  );
  
  await app.listen(4000);
  console.log(`🚀 Server running at: http://localhost:4000`);
   
}
bootstrap();
